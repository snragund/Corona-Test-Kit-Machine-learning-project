# corona_test_kit
An online tool to check between Influenza &amp; COVID19
